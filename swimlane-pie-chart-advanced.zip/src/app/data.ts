export var single = [
  {
    "name": "SMS Magic Link",
    "value": 4
  },
  {
    "name": "SMS Passcode",
    "value": 1
  },
  {
    "name": "Soft Token",
    "value": 3
  },
    {
    "name": "Security Key",
    "value": 0
  },
  {
    "name": "Device Biometrics",
    "value": 0
  },
  {
    "name": "Email Passcode",
    "value": 0
  },
  {
    "name": "Email Magic Link",
    "value": 0
  },
  {
    "name": "Voice Call",
    "value": 0
  },
];